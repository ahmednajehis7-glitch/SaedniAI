# Saedni AI Android

هذا مشروع Android أولي مبني على واجهة Saedni AI الحالية.

## التشغيل
1. افتح المشروع في Android Studio.
2. انتظر مزامنة Gradle.
3. شغّل التطبيق على هاتف Android أو Emulator.
4. التطبيق يفتح `index.html` من مجلد assets.
5. الاتصال بالـ Gemini يتم عبر Google Apps Script الموجود داخل الواجهة، لذلك لا يتم وضع مفتاح Gemini داخل التطبيق.

## مهم
لأن الميكروفون يعتمد على Web Speech API داخل WebView، قد تختلف دعمه حسب إصدار Android/WebView. تم إضافة صلاحية RECORD_AUDIO وتجهيز WebChromeClient.
